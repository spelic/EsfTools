namespace EsfParser.Esf
{
    public interface IEsfTagModel
    {
        string TagName { get; }
    }
}