namespace EsfParser.Tags
{
    public enum DataType
    {
        BIN, CHA, DBCS, HEX, MIX,
        NUM, NUMC, PACK, PACF,
        UNICODE, ANYCHAR, ANYNUMERIC
    }
}
